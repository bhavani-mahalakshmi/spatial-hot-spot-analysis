# Project-1-Group-13

### This repository implements the Project Phase 1 for the course CSE 511 with bonus. 

The docker image mentioned below has Spark version 3.3.2, Scala version 2.12.15 and Java version 11.0.16. The `build.sbt` file is modified accordingly to these new versions.

Following are the directions to run the implementation:
1. Pull the docker image from hub:\
    Link: [https://hub.docker.com/r/bgowrisa/group13-project1-phase1-bonus](https://hub.docker.com/r/bgowrisa/group13-project1-phase1-bonus)
    ```
    docker pull bgowrisa/group13-project1-phase1-bonus:v0
    ```
    Note: The following docker image is built on Apple Silicon chipset. So, for windows users if TCP/IP error is thrown then kindly go to Settings > General > Select checkbox "Expose daemon on tcp ... without TLS". The settings page should look like the below figure.
    \
    <img src="docker_desktop.png" alt="Docker desktop settings" width="100%" height="100%" title="Docker desktop settings">
    
2. Run the docker image in interactive mode:
    ```shell
    docker run --rm -it bgowrisa/group13-project1-phase1-bonus:v0 
    ```
3. Change directory to project folder:
    ```shell
    cd /final/Project-1-Group-13/cse511
    ```
4. Submit the spark job using spark-submit:\
    The project folder contains the compiled jar file preloaded and log4j.properties file to configure loggings.\
    In case if we want to compile jar file, follow the given steps then execute the spark submit command:
    * Renaming the existing jar file in project folder and in target/scala-2.12 directory:
        ```shell
        mv [Group-13][Project1][Phase1].jar [Group-13][Project1][Phase1].jar.bkp
        mv target/scala-2.12/CSE511-assembly-0.1.0.jar target/scala-2.12/CSE511-assembly-0.1.0.jar.bkp
        ```
    * Execute the following command to compile new jar file:
        ```shell
        sbt assembly
        ```
    * Copy the jar file to project folder:
        ```shell
        cp target/scala-2.12/CSE511-assembly-0.1.0.jar [Group-13][Project1][Phase1].jar
        ```
    Now exceute to following command:
    ```shell
    log4j_setting="-Dlog4j.configuration=file:log4j.properties"
    spark-submit --conf "spark.driver.extraJavaOptions=${log4j_setting}" \
    --conf "spark.executor.extraJavaOptions=${log4j_setting}" \
    [Group-13][Project1][Phase1].jar \
    result/output \
    rangequery src/resources/arealm10000.csv -93.63173,33.0183,-93.359203,33.219456 \
    rangejoinquery src/resources/arealm10000.csv src/resources/zcta10000.csv \
    distancequery src/resources/arealm10000.csv -88.331492,32.324142 1 \
    distancejoinquery src/resources/arealm10000.csv src/resources/arealm10000.csv 0.1
    ```
    <img src="terminal_output.png" alt="Program output" width="100%" height="100%" title="Program output">

### Contributions:
| Contributors      | Contribution |
| ----------- | ----------- |
| Saurabh Arjun Sawant      | Implemented ST_Contains function, created repository and managed readme file, bonus implementation including configuration and docker image creation |
| Bhavani Mahalakshmi Gowri Sankar   | Implemented ST_Within function, managed readme file, configuring, creating and pushing the docker image for bonus implmentation        |
| Satya PranaY Manas Nunna  | Implemented helper functions for ST_Contains and ST_Within functions(getPointCoordinate,getDistanceBetweenPoints), managed readme file, configuring and testing the docker image for bonus implementation|
